import serverless_sdk
sdk = serverless_sdk.SDK(
    org_id='leobardogama',
    application_name='my-aws-python-flask-api-app',
    app_uid='j6jqHdCwGkwJcPvwpQ',
    org_uid='33999e18-7b41-4cbd-bbb4-55aff807acba',
    deployment_uid='9f060e22-3351-40e1-b9ba-679315070a12',
    service_name='my-aws-python-flask-api-app',
    should_log_meta=True,
    should_compress_logs=True,
    disable_aws_spans=False,
    disable_http_spans=False,
    stage_name='dev',
    plugin_version='5.5.1',
    disable_frameworks_instrumentation=False,
    serverless_platform_stage='prod'
)
handler_wrapper_kwargs = {'function_name': 'my-aws-python-flask-api-app-dev-api', 'timeout': 6}
try:
    user_handler = serverless_sdk.get_user_handler('wsgi_handler.handler')
    handler = sdk.handler(user_handler, **handler_wrapper_kwargs)
except Exception as error:
    e = error
    def error_handler(event, context):
        raise e
    handler = sdk.handler(error_handler, **handler_wrapper_kwargs)
